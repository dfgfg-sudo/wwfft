/**
 * 主入口文件
 * @module index
 */

const express = require('express');
const app = express();

app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'Hello World', status: 'ok' });
});

app.get('/api/docs', (req, res) => {
  res.json({ documents: [], total: 0 });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
