#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""工具函数模块"""

import os
import json
from typing import List, Dict, Optional

def load_config(path: str) -> dict:
    """加载配置文件"""
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def get_file_list(directory: str) -> List[str]:
    """获取目录下所有文件"""
    files = []
    for item in os.listdir(directory):
        full_path = os.path.join(directory, item)
        if os.path.isfile(full_path):
            files.append(full_path)
    return files

def format_size(bytes_val: int) -> str:
    """格式化文件大小"""
    if bytes_val == 0:
        return '0 B'
    units = ['B', 'KB', 'MB', 'GB']
    k = 1024
    i = 0
    size = bytes_val
    while size >= k and i < len(units) - 1:
        size /= k
        i += 1
    return f'{size:.2f} {units[i]}'
